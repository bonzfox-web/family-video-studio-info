# Alexa Parent Publisher - reviewer copy

Prepared for owner review. This archive has NOT been uploaded, published or submitted to Google. It contains the same allowlisted adult-publisher source files as the running application, a synthetic test-pattern video and this guide. The interface is Russian; English explanations are below. Source hashes are in manifest.json.

## Requirements and installation (Windows)

Install Python 3.11 or later from https://www.python.org/downloads/windows/ if it is not already available. Extract the whole ZIP into a new folder. Open PowerShell in that folder:

    .\setup.ps1
    .\start_parent.ps1

Setup creates a virtual environment and installs the six pinned top-level packages from PyPI. Transitive dependencies are resolved by pip; this is a source package, not a bundled executable or a fully locked environment. It does not need FFmpeg, OpenAI, CapCut, or the family editor. On first start a NEW local access code is printed in the terminal. Use that code at http://127.0.0.1:8788/ . No owner's access code or Google credentials are included. Keep the terminal open; Ctrl+C stops this copy.

Port 8788 must be free. Do not stop an existing production publisher just to try this archive: test on a separate computer or when the owner's publisher is already stopped. This package retains the actual loopback-only binding and does not open access to the home network or Internet.

If PowerShell scripts are blocked by system policy, use the equivalent Python commands without changing that policy:

    py -3 -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt
    .\.venv\Scripts\python.exe -m parent_uploader.app

## Local review without a Google connection

1. Enter the new local access code (parent-only login).
2. Read the privacy policy and YouTube Terms, then personally accept them if you agree. No acceptance record is shipped.
3. Choose samples/synthetic-test.mp4 and press Add for review (Добавить для проверки).
4. Preview the three-second synthetic color-pattern video. Import does not upload anything.
5. Inspect the title, description, visibility and audience controls. Private is the default. Upload requires the parent's explicit review/rights and policy confirmations AND a Google connection. Do not confirm rights for a file you do not own.
6. The local delete action removes only this copy's imported file/record; it does not delete videos on YouTube. Use disposable synthetic files to test deletion.

## OAuth and actual upload review - NOT preconfigured

This clean copy starts disconnected. No client_secret.json, token.json, OAuth identity, test account or signed-in session is supplied. OAuth requests only https://www.googleapis.com/auth/youtube.upload. Source uses resumable videos.insert with snippet,status; it does not request channel analytics or comments. It does not enforce a fixed channel ID.

Audited owner project: mfk110-alexa-parent-upload (357990483179). It is currently External/Testing, so authorization is limited to its configured test users. The owner and Google must agree how an authorized reviewer will access that project's OAuth client before the audit can proceed. The documentation website is not interactive app access. Do not substitute a reviewer's own project as proof that the owner's project has been authorized or approved.

If Google agrees a reviewer setup, the desktop OAuth client configuration is provided separately through an agreed channel and placed at parent_uploader/client_secret.json. An eligible reviewer runs .\connect_parent.ps1, reviews the actual Google consent and signs in themselves. Tokens then remain in that reviewer's local parent_uploader folder. Never send the owner's token.json, access code or signed-in browser session.

For an independently configured functional test only, a reviewer may use their own desktop OAuth client and their own account/channel. That tests the code, not the owner's Google configuration or its private-only restriction. The reviewer manually chooses a synthetic MP4, title, description, visibility and audience and initiates upload. Do not upload family footage. Google may retain private-only visibility on an unverified API project regardless of the selected setting.

Disconnect YouTube (Отключить YouTube) requests revocation with Google and removes local tokens and cached YouTube data. A grant can affect other connections in the same Cloud project; do not test revocation against the owner's live connection. If Google cannot confirm revocation, the UI reports that and links to Google Account permissions. Connection checking is daily while the server runs; cached YouTube links/status expire after 30 days. Local MP4/history remain until local deletion.

## Public documents and supplementary demonstration

Homepage: https://bonzfox-web.github.io/family-video-studio-info/
Privacy policy version 2026-10-06.5: https://bonzfox-web.github.io/family-video-studio-info/privacy.html
YouTube Terms: https://www.youtube.com/t/terms
Unlisted workflow demonstration: https://www.youtube.com/watch?v=W6MMblxTiBQ
Public contact: bonz.fox@gmail.com

The demonstration shows the separate family editor and adult publisher. The child-facing editor is deliberately not included in this adult-only package, and has no YouTube API routes or credentials. The full family workflow, OpenAI processing and manual CapCut step must still be disclosed in the audit. This copy is not evidence of Google policy approval, and the demonstration does not show fresh OAuth consent or CapCut editing.

## Archive contents and exclusions

Included: allowlisted publisher Python/HTML/CSS/JavaScript and policy, setup/start/connect scripts, requirements, synthetic MP4, source/file hashes. Excluded: all runtime data, config/password hashes/cookie keys, client secrets and tokens (including pending/backups), .env files, owner/family media, logs, credentials, .venv and caches. The source is copied unchanged; hashing and the explicit allowlist verify packaging, not a comprehensive security audit.

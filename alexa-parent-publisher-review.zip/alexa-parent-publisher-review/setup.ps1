$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (Get-Command py -ErrorAction SilentlyContinue) { $pythonLauncher = 'py'; $launcherArgs = @('-3') }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $pythonLauncher = 'python'; $launcherArgs = @() }
else { throw 'Install Python 3.11 or later from python.org first.' }
& $pythonLauncher @launcherArgs -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)"
if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or later is required.' }
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    & $pythonLauncher @launcherArgs -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create virtual environment.' }
}
& '.venv\Scripts\python.exe' -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
Write-Host 'Setup complete. Run .\start_parent.ps1. Read README.md before connecting Google.'

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) { throw 'Run .\setup.ps1 first.' }
if (-not (Test-Path -LiteralPath 'parent_uploader\client_secret.json')) { throw 'Read README.md: OAuth configuration and eligible reviewer access must be arranged separately.' }
& '.venv\Scripts\python.exe' -m parent_uploader.app --connect

"""Own and stop only subprocess trees started by this application."""
import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path


class WorkerManager:
    def __init__(self, root: Path, temp_root: Path, on_event, on_cancel):
        self.root = root
        self.temp_root = temp_root.resolve()
        self.on_event = on_event
        self.on_cancel = on_cancel
        self.lock = threading.RLock()
        self.active = {}
        self.closing = False

    def start(self, job_id: str, kind: str, job: dict, output: Path):
        if kind != "publish":
            raise ValueError("The adult publisher can only publish imported videos")
        # IDs come from the server, but keep all temporary paths confined anyway.
        folder = (self.temp_root / job_id).resolve()
        if folder.parent != self.temp_root:
            raise ValueError("Неверный идентификатор задачи")
        with self.lock:
            if self.closing:
                raise RuntimeError("Приложение выключается")
            if job_id in self.active:
                raise RuntimeError("Задача уже выполняется")
            folder.mkdir(parents=True, exist_ok=True)
            flags = (subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW) if os.name == "nt" else 0
            environment = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
            process = subprocess.Popen([sys.executable, "-u", str(self.root / "job_worker.py")],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                       text=True, encoding="utf-8", env=environment, creationflags=flags,
                                       start_new_session=os.name != "nt")
            job_object = None
            if os.name == "nt":
                try:
                    from windows_job import WindowsJob
                    job_object = WindowsJob(process)
                except OSError:
                    process.kill()
                    process.wait(timeout=2)
                    raise RuntimeError("Windows не разрешила создать управляемую задачу обработки")
            record = {"process": process, "kind": kind, "folder": folder, "cancelled": False,
                      "finished": False, "job_object": job_object}
            self.active[job_id] = record
            try:
                json.dump({"job": job, "kind": kind, "output": str(output), "root": str(self.root),
                           "temp_root": str(folder)}, process.stdin, ensure_ascii=False)
                process.stdin.close()
            except Exception:
                if job_object:
                    job_object.close()
                process.kill()
                self.active.pop(job_id, None)
                raise
            threading.Thread(target=self._monitor, args=(job_id, record), daemon=True).start()

    def _cleanup(self, folder: Path):
        resolved = folder.resolve()
        if resolved.parent == self.temp_root:
            shutil.rmtree(resolved, ignore_errors=True)

    def _monitor(self, job_id, record):
        final = False
        process = record["process"]
        try:
            for line in process.stdout:
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                with self.lock:
                    if record["cancelled"]:
                        break
                    if event.get("event") in ("result", "error"):
                        final = True
                        record["finished"] = True
                    self.on_event(job_id, record["kind"], event)
            process.wait()
            with self.lock:
                if not final and not record["cancelled"]:
                    self.on_event(job_id, record["kind"], {"event": "error", "error": "Процесс обработки неожиданно завершился"})
        except (OSError, UnicodeError):
            with self.lock:
                if not record["cancelled"]:
                    self.on_event(job_id, record["kind"], {"event": "error", "error": "Связь с процессом обработки прервана"})
        finally:
            if record["job_object"]:
                record["job_object"].close()
            process.stdout.close()
            with self.lock:
                if self.active.get(job_id) is record:
                    self.active.pop(job_id, None)
            self._cleanup(record["folder"])

    def stop_all(self):
        with self.lock:
            self.closing = True
            records = list(self.active.items())
            for job_id, record in records:
                record["cancelled"] = True
                if not record["finished"]:
                    self.on_cancel(job_id, record["kind"])
        running = [record["process"] for _, record in records if record["process"].poll() is None]
        if running and os.name == "nt":
            for _, record in records:
                record["job_object"].close()
        elif running:
            import signal
            for process in running:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        for process in running:
            if process.poll() is None:
                process.kill()
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
        for _, record in records:
            self._cleanup(record["folder"])

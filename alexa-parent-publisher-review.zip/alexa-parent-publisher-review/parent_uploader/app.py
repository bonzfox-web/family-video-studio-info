"""Adult-only local publisher. No child routes or shared studio job store."""
from __future__ import annotations
import asyncio
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from pathlib import Path
from contextlib import asynccontextmanager
import uvicorn
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from .worker_manager import WorkerManager
from .youtube_metadata import validate_metadata
from .youtube_lifecycle import clear_api_data, expire_api_data, CHECK_INTERVAL, RETRY_INTERVAL
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RENDERED = DATA / "rendered"
JOBS_PATH = DATA / "jobs.json"
CONFIG_PATH = DATA / "config.json"
for folder in (DATA, RENDERED):
    folder.mkdir(parents=True, exist_ok=True)
LOCK = threading.RLock()
YOUTUBE_DISCONNECTING = False
YOUTUBE_CHECKING = False
PRIVACY_VERSION = "2026-10-06.5"
failures = {}
def save_json(path: Path, value: object) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)

def secret_hash(value: str, salt: str) -> str:
    return hashlib.scrypt(value.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1).hex()

if not CONFIG_PATH.exists():
    salt = secrets.token_hex(16)
    password = secrets.token_urlsafe(18)
    save_json(CONFIG_PATH, {"salt": salt, "parent_hash": secret_hash(password, salt),
                           "cookie_key": secrets.token_hex(32)})
    print("Parent publisher initial access code: " + password)
CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

@asynccontextmanager
async def lifespan(application):
    recover_interrupted()
    stop_maintenance = threading.Event()
    maintenance = threading.Thread(target=youtube_maintenance_loop, args=(stop_maintenance,), daemon=True)
    maintenance.start()
    try:
        yield
    finally:
        stop_maintenance.set()
        WORKERS.stop_all()

app = FastAPI(title="Родительская публикация", docs_url=None, redoc_url=None,
              lifespan=lifespan)

def jobs() -> dict:
    if not JOBS_PATH.exists():
        return {}
    return json.loads(JOBS_PATH.read_text(encoding="utf-8"))

def update_job(job_id: str, **changes) -> None:
    with LOCK:
        all_jobs = jobs()
        if job_id not in all_jobs:
            return
        all_jobs[job_id].update(changes)
        save_json(JOBS_PATH, all_jobs)

def youtube_state() -> dict:
    path = DATA / "youtube_connection.json"
    try:
        state = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
        return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}

def expire_youtube_records(now: float) -> None:
    with LOCK:
        records = jobs()
        if expire_api_data(records, now):
            save_json(JOBS_PATH, records)

def forget_youtube_access(now: float) -> None:
    """Call under LOCK after a definitive access rejection, never a timeout."""
    (ROOT / "token.json").unlink(missing_ok=True)
    records = jobs()
    clear_api_data(records, "access_lost")
    save_json(JOBS_PATH, records)
    save_json(DATA / "youtube_connection.json", {"check_status": "reauthorize", "last_attempt": now,
                                               "revocation_unconfirmed": False})

def check_youtube_access(stop: threading.Event, now: float | None = None) -> None:
    global YOUTUBE_CHECKING
    now = time.time() if now is None else now
    with LOCK:
        token_path = ROOT / "token.json"
        if stop.is_set() or YOUTUBE_CHECKING or YOUTUBE_DISCONNECTING or not token_path.is_file():
            return
        if any(job["status"] == "uploading" for job in jobs().values()):
            return
        state = youtube_state()
        interval = CHECK_INTERVAL if state.get("check_status") == "valid" else RETRY_INTERVAL
        if state.get("check_status") != "reauthorize" and now - state.get("last_attempt", 0) < interval:
            return
        YOUTUBE_CHECKING = True
    try:
        snapshot = token_path.read_bytes()
        from .youtube import refresh_access
        try:
            result, refreshed = refresh_access(json.loads(snapshot))
        except ValueError:
            result, refreshed = "unavailable", None
        with LOCK:
            if stop.is_set() or not token_path.is_file() or token_path.read_bytes() != snapshot:
                return
            if result == "reauthorize":
                forget_youtube_access(now)
            else:
                state = youtube_state()
                state.update(check_status=result, last_attempt=now)
                if result == "valid":
                    save_json(token_path, refreshed)
                    state.update(last_checked=now, revocation_unconfirmed=False)
                save_json(DATA / "youtube_connection.json", state)
    finally:
        with LOCK:
            YOUTUBE_CHECKING = False

def youtube_maintenance_loop(stop: threading.Event) -> None:
    while not stop.is_set():
        try:
            expire_youtube_records(time.time())
            check_youtube_access(stop)
        except Exception:
            print("Проверка данных YouTube отложена из-за локальной ошибки.", flush=True)
        stop.wait(60)

def sign(role: str, expiry: int) -> str:
    body = f"{role}.{expiry}"
    digest = hmac.new(bytes.fromhex(CONFIG["cookie_key"]), body.encode(), "sha256").hexdigest()
    return f"{body}.{digest}"

def role_of(request: Request) -> str | None:
    try:
        role, expiry, digest = request.cookies.get("parent_publisher", "").split(".")
        expected = sign(role, int(expiry)).split(".")[-1]
        if role == "parent" and int(expiry) > time.time() and hmac.compare_digest(digest, expected):
            return role
    except (ValueError, AttributeError):
        pass
    return None

def require(request: Request, expected: str | None = None) -> str:
    role = role_of(request)
    if not role or expected and role != expected:
        raise HTTPException(403, "Требуется вход")
    return role

def same_origin(request: Request) -> None:
    origin = request.headers.get("origin")
    if origin and origin != f"{request.url.scheme}://{request.headers.get('host')}":
        raise HTTPException(403, "Неверный источник запроса")

def policy_is_accepted() -> bool:
    try:
        record = json.loads((DATA / "policy_acceptance.json").read_text(encoding="utf-8"))
        return (isinstance(record, dict) and record.get("version") == PRIVACY_VERSION
                and record.get("role") == "parent" and type(record.get("accepted_at")) in (int, float)
                and 0 < record["accepted_at"] <= time.time())
    except (OSError, ValueError, TypeError):
        return False

def policy_state() -> dict:
    return {"accepted": policy_is_accepted(), "version": PRIVACY_VERSION}

@app.middleware("http")
async def policy_gate(request: Request, call_next):
    # Reject before FastAPI parses multipart uploads; hiding the form is not sufficient.
    path = request.url.path
    if path == "/api/jobs" or path.startswith("/api/jobs/") or path.startswith("/watch/"):
        if not role_of(request):
            return JSONResponse({"detail": "Требуется вход"}, status_code=403)
        if not policy_is_accepted():
            if path.startswith("/watch/"):
                return RedirectResponse("/", status_code=303)
            return JSONResponse({"detail": "Родителю нужно принять актуальную политику перед работой.",
                                 "code": "policy_required", "policy": policy_state()}, status_code=428)
    return await call_next(request)

@app.post("/api/policy/accept")
async def accept_policy(request: Request):
    same_origin(request)
    require(request, "parent")
    payload = await request.json()
    if not isinstance(payload, dict) or payload.get("accepted") is not True:
        raise HTTPException(400, "Подтвердите принятие политики")
    if payload.get("version") != PRIVACY_VERSION:
        raise HTTPException(409, "Политика обновлена. Перезагрузите страницу и прочитайте новую версию.")
    with LOCK:
        if not policy_is_accepted():
            save_json(DATA / "policy_acceptance.json", {"version": PRIVACY_VERSION,
                      "accepted_at": time.time(), "role": "parent"})
    return {"policy": policy_state()}

@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse((ROOT / "templates" / "index.html").read_text(encoding="utf-8"), headers={"Cache-Control":"no-store"})

@app.get("/privacy", response_class=HTMLResponse)
def privacy():
    document = (ROOT / "public-site" / "privacy.html").read_text(encoding="utf-8")
    return HTMLResponse(document.replace('href="style.css"', 'href="/assets/legal.css"')
                        .replace('href="privacy.html"', 'href="/privacy"')
                        .replace('href="index.html"', 'href="https://bonzfox-web.github.io/family-video-studio-info/"'),
                        headers={"Cache-Control": "no-store"})

@app.get("/assets/legal.css")
def legal_css():
    return FileResponse(ROOT / "public-site" / "style.css", media_type="text/css")

@app.get("/api/youtube/connection")
def youtube_connection(request: Request):
    require(request, "parent")
    with LOCK:
        state = youtube_state()
        return {"token_saved": (ROOT / "token.json").is_file(),
                "disconnecting": YOUTUBE_DISCONNECTING,
                "checking": YOUTUBE_CHECKING,
                "check_status": state.get("check_status", "not_checked"),
                "last_checked": state.get("last_checked"),
                "revocation_unconfirmed": state.get("revocation_unconfirmed", False),
                "privacy_version": PRIVACY_VERSION}

@app.post("/api/youtube/disconnect")
def disconnect_youtube(request: Request):
    global YOUTUBE_DISCONNECTING
    same_origin(request)
    require(request, "parent")
    with LOCK:
        if YOUTUBE_DISCONNECTING or YOUTUBE_CHECKING or any(job["status"] == "uploading" for job in jobs().values()):
            raise HTTPException(409, "Дождитесь завершения загрузки или проверки подключения YouTube")
        YOUTUBE_DISCONNECTING = True
    try:
        from .youtube import revoke_connection
        revoked = revoke_connection(ROOT / "token.json")
        with LOCK:
            (ROOT / "token.json").unlink(missing_ok=True)
            records = jobs()
            clear_api_data(records, "disconnected")
            for job in records.values():
                if job["status"] in ("uploaded", "approved"):
                    job["error"] = None
            save_json(JOBS_PATH, records)
            save_json(DATA / "youtube_connection.json", {"check_status": "disconnected", "revocation_unconfirmed": not revoked})
        return {"ok": True, "revoked": revoked}
    except OSError as exc:
        raise HTTPException(500, "Не удалось удалить часть локальных данных подключения. Повторите отключение.") from exc
    finally:
        with LOCK:
            YOUTUBE_DISCONNECTING = False

@app.get("/assets/app.css")
def css():
    return FileResponse(ROOT / "assets" / "app.css", media_type="text/css")

@app.get("/assets/app.js")
def js():
    return FileResponse(ROOT / "assets" / "app.js", media_type="text/javascript", headers={"Cache-Control": "no-store"})

@app.post("/api/login")
async def login(request: Request):
    same_origin(request)
    ip = request.client.host if request.client else "?"
    count, start = failures.get(ip, (0, time.time()))
    if time.time() - start > 600:
        count, start = 0, time.time()
    if count >= 10:
        raise HTTPException(429, "Попробуйте позже")
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(400, "Неверный запрос входа")
    role = payload.get("role")
    password = str(payload.get("password", ""))
    if role != "parent" or not hmac.compare_digest(
        secret_hash(password, CONFIG["salt"]), CONFIG[f"{role}_hash"]
    ):
        failures[ip] = (count + 1, start)
        raise HTTPException(403, "Неверный код")
    failures.pop(ip, None)
    response = JSONResponse({"role": role, "policy": policy_state()})
    response.set_cookie("parent_publisher", sign(role, int(time.time() + 8 * 3600)), httponly=True,
                        samesite="strict", max_age=8 * 3600)
    return response

@app.post("/api/logout")
def logout(request: Request):
    same_origin(request)
    response = JSONResponse({"ok": True})
    response.delete_cookie("parent_publisher")
    return response

@app.get("/api/me")
def me(request: Request):
    role = role_of(request)
    return {"role": role, "policy": policy_state() if role else None}

@app.get("/api/jobs")
def list_jobs(request: Request):
    require(request, "parent")
    expire_youtube_records(time.time())
    with LOCK:
        values = sorted(jobs().values(), key=lambda x: x["created"], reverse=True)
    return [{**{key:value for key,value in job.items() if key not in ("sources","output")},
             "has_video":(RENDERED / f"{job['id']}.mp4").is_file()} for job in values]

def publish_job(job_id: str) -> None:
    with LOCK:
        job = jobs()[job_id]
    try:
        WORKERS.start(job_id, "publish", job, RENDERED / f"{job_id}.mp4")
    except Exception as exc:
        update_job(job_id, status="approved", error=str(exc)[:300])

@app.post("/api/jobs/{job_id}/publish")
async def retry_publish(request: Request, job_id: str):
    same_origin(request)
    require(request, "parent")
    try:
        payload = await request.json()
        metadata = validate_metadata(payload)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if payload.get("reviewed") is not True:
        raise HTTPException(400, "Подтвердите личный просмотр и право отправить этот ролик")
    if payload.get("privacy_accepted") is not True or payload.get("privacy_version") != PRIVACY_VERSION:
        raise HTTPException(400, "Прочитайте и примите актуальную политику перед отправкой на YouTube")
    with LOCK:
        if YOUTUBE_DISCONNECTING or YOUTUBE_CHECKING:
            raise HTTPException(409, "Дождитесь проверки или отключения YouTube")
        job = jobs().get(job_id)
        if not job or job["status"] != "approved":
            raise HTTPException(409, "Сначала одобрите ролик")
        if any(record["status"] == "uploading" for record in jobs().values()):
            raise HTTPException(409, "Дождитесь завершения предыдущей загрузки YouTube")
        if not (ROOT / "token.json").is_file():
            raise HTTPException(409, "Сначала подключите YouTube на компьютере")
        if not (RENDERED / f"{job_id}.mp4").is_file():
            raise HTTPException(409, "Готовое видео не найдено")
        update_job(job_id, status="uploading", error=None, youtube_metadata=metadata,
                   made_for_kids=metadata["made_for_kids"],
                   privacy_acceptance={"version": PRIVACY_VERSION, "accepted_at": time.time(), "role": "parent"})
    publish_job(job_id)
    return {"ok": True}

class StudioServer(uvicorn.Server):
    def run(self, sockets=None):
        # Networking uses a selector on Windows; workers use synchronous Popen.
        # This avoids Proactor shutdown callbacks on closed video connections.
        if os.name == "nt":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        try:
            return super().run(sockets)
        except KeyboardInterrupt:
            pass
        finally:
            WORKERS.stop_all()

    async def shutdown(self, sockets=None):
        print("Останавливаем обработку видео и закрываем соединения…", flush=True)
        WORKERS.stop_all()
        await super().shutdown(sockets)

@app.middleware("http")
async def local_host_guard(request: Request, call_next):
    if request.url.hostname not in ("localhost", "127.0.0.1"):
        return JSONResponse({"detail":"Откройте родительское окно на этом компьютере через localhost."}, status_code=403)
    if request.headers.get("sec-fetch-site") == "cross-site":
        return JSONResponse({"detail":"Внешний источник запрещён"}, status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = "no-store"
    return response

@app.post("/api/jobs")
async def import_video(request: Request, video_file: UploadFile = File(...)):
    same_origin(request)
    require(request, "parent")
    if not (video_file.filename or "").lower().endswith(".mp4"):
        await video_file.close()
        raise HTTPException(400, "Выберите готовый MP4")
    job_id = secrets.token_hex(12)
    output = RENDERED / f"{job_id}.mp4"
    temporary = output.with_suffix(".part")
    total = 0
    try:
        first = await video_file.read(1024 * 1024)
        if len(first) < 12 or first[4:8] != b"ftyp":
            raise HTTPException(400, "Файл не похож на контейнер MP4")
        with temporary.open("xb") as stream:
            chunk = first
            while chunk:
                total += len(chunk)
                if total > 2 * 1024**3:
                    raise HTTPException(413, "Размер MP4 превышает 2 ГБ")
                stream.write(chunk)
                chunk = await video_file.read(1024 * 1024)
        temporary.replace(output)
        with LOCK:
            records = jobs()
            records[job_id] = {"id":job_id, "created":time.time(), "status":"approved",
                              "filename":Path(video_file.filename).name, "error":None}
            save_json(JOBS_PATH, records)
        return {"ok":True, "id":job_id}
    except Exception:
        temporary.unlink(missing_ok=True)
        output.unlink(missing_ok=True)
        raise
    finally:
        await video_file.close()

@app.get("/api/jobs/{job_id}/video")
def video(request: Request, job_id: str):
    require(request, "parent")
    job = jobs().get(job_id)
    if not job or not (RENDERED / f"{job_id}.mp4").is_file():
        raise HTTPException(404, "Видео не найдено")
    return FileResponse(RENDERED / f"{job_id}.mp4", media_type="video/mp4")

@app.post("/api/jobs/{job_id}/delete")
def delete_import(request: Request, job_id: str):
    same_origin(request)
    require(request, "parent")
    with LOCK:
        records = jobs()
        job = records.get(job_id)
        if not job:
            raise HTTPException(404, "Видео не найдено")
        if job["status"] == "uploading":
            raise HTTPException(409, "Дождитесь завершения загрузки")
        (RENDERED / f"{job_id}.mp4").unlink(missing_ok=True)
        del records[job_id]
        save_json(JOBS_PATH, records)
    return {"ok":True}

def worker_event(job_id: str, kind: str, event: dict):
    if kind != "publish":
        return
    with LOCK:
        if event["event"] == "error":
            update_job(job_id, status="approved", error=event["error"])
            if event.get("access_lost"):
                forget_youtube_access(time.time())
        elif event["event"] == "result":
            update_job(job_id, status="uploaded", youtube_url=event["youtube_url"],
                       youtube_privacy=event.get("youtube_privacy"),
                       youtube_data_received_at=time.time(), youtube_data_removed=None, error=None)

def worker_cancel(job_id: str, kind: str):
    update_job(job_id, status="approved",
               error="Загрузка прервана. Проверьте YouTube Studio перед повторной отправкой.")

WORKERS = WorkerManager(ROOT, DATA / "work", worker_event, worker_cancel)

def recover_interrupted():
    for job_id, job in jobs().items():
        if job["status"] == "uploading":
            worker_cancel(job_id, "publish")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--connect", action="store_true")
    args = parser.parse_args()
    if args.connect:
        from .youtube import credentials
        credentials(ROOT / "client_secret.json", ROOT / "token.json", interactive=True)
        print("YouTube подключён в родительском инструменте.")
    else:
        print("Родительская публикация: http://127.0.0.1:8788/")
        StudioServer(uvicorn.Config(app, host="127.0.0.1", port=8788,
                                   timeout_graceful_shutdown=3, timeout_keep_alive=2)).run()

"""Retention for API-returned fields only; local videos and user text are kept."""
import math

API_DATA_TTL = 30 * 86400
CHECK_INTERVAL = 86400
RETRY_INTERVAL = 3600
API_FIELDS = ("youtube_url", "youtube_privacy", "youtube_data_received_at")


def clear_api_data(records: dict, reason: str) -> bool:
    changed = False
    for job in records.values():
        if any(job.get(field) is not None for field in API_FIELDS):
            for field in API_FIELDS:
                job.pop(field, None)
            job["youtube_data_removed"] = reason
            changed = True
    return changed


def expire_api_data(records: dict, now: float) -> bool:
    changed = False
    for job in records.values():
        if not job.get("youtube_url") and not job.get("youtube_privacy"):
            continue
        # Older records have no upload timestamp. Creation is a conservative
        # lower bound, so migration never extends their retention window.
        received = job.get("youtube_data_received_at", job.get("created", 0))
        if not isinstance(received, (int, float)) or not math.isfinite(received) or received > now:
            received = 0
        if now - received >= API_DATA_TTL:
            changed = clear_api_data({"job": job}, "expired") or changed
    return changed

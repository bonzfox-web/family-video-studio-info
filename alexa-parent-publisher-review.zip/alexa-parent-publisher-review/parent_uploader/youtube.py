"""Parent-owned YouTube authorization and explicitly requested uploads."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import requests

from google.auth.transport.requests import Request
from google.auth.exceptions import RefreshError
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError
if __package__:
    from .youtube_metadata import validate_metadata
else:
    from youtube_metadata import validate_metadata

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


class YouTubeAccessLost(RuntimeError):
    pass


def access_lost_error(exc: Exception) -> bool:
    if isinstance(exc, RefreshError):
        return any(isinstance(arg, dict) and arg.get("error") == "invalid_grant" for arg in exc.args)
    return isinstance(exc, HttpError) and exc.resp.status == 401


def refresh_access(stored: dict) -> tuple[str, dict | None]:
    """Daily bounded check. Only invalid_grant proves reauthorization is needed.

    Network/HTTP/configuration errors never delete a user's connection.
    No response body, exception message, or secret leaves this helper.
    """
    required = ("refresh_token", "client_id", "client_secret")
    if not isinstance(stored, dict) or any(not isinstance(stored.get(key), str) or not stored[key] for key in required):
        return "unavailable", None
    try:
        response = requests.post("https://oauth2.googleapis.com/token",
                                 data={**{key: stored[key] for key in required},
                                       "grant_type": "refresh_token"},
                                 timeout=(5, 10), allow_redirects=False)
        payload = response.json()
        if not isinstance(payload, dict):
            return "unavailable", None
        if response.status_code == 400 and payload.get("error") == "invalid_grant":
            return "reauthorize", None
        seconds = payload.get("expires_in")
        if response.status_code != 200 or not isinstance(payload.get("access_token"), str) or not payload["access_token"]:
            return "unavailable", None
        if not isinstance(seconds, (int, float)) or not 0 < seconds <= 86400:
            return "unavailable", None
        refreshed = {**stored, "token": payload["access_token"],
                     "expiry": (datetime.now(timezone.utc) + timedelta(seconds=seconds)).strftime("%Y-%m-%dT%H:%M:%SZ")}
        if isinstance(payload.get("refresh_token"), str) and payload["refresh_token"]:
            refreshed["refresh_token"] = payload["refresh_token"]
        return "valid", refreshed
    except (requests.RequestException, ValueError):
        return "unavailable", None


def revoke_connection(token_path: Path) -> bool:
    """Best-effort Google revocation; caller removes local data even offline.

    Never return remote response bodies or exceptions that might contain tokens.
    """
    if not token_path.is_file():
        return False
    try:
        stored = json.loads(token_path.read_text(encoding="utf-8"))
        token = stored.get("refresh_token") or stored.get("token")
        if not isinstance(token, str) or not token:
            return False
        response = requests.post("https://oauth2.googleapis.com/revoke",
                                 data={"token": token}, timeout=(5, 10),
                                 allow_redirects=False)
        return response.status_code == 200
    except (requests.RequestException, OSError, ValueError, AttributeError):
        return False


def credentials(client_secret: Path, token_path: Path, interactive: bool = False) -> Credentials:
    creds = Credentials.from_authorized_user_file(str(token_path), SCOPES) if token_path.is_file() else None
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as exc:
            if access_lost_error(exc):
                if interactive:
                    creds = None
                else:
                    raise YouTubeAccessLost("Доступ Google истёк или отозван. Подключите YouTube заново.") from None
            else:
                raise RuntimeError("Не удалось проверить доступ Google. Попробуйте позже.") from None
    if not creds or not creds.valid:
        if not interactive:
            raise RuntimeError("Подключите аккаунт YouTube на компьютере")
        if not client_secret.is_file():
            raise RuntimeError("Добавьте файл client_secret.json из Google Cloud")
        flow = InstalledAppFlow.from_client_secrets_file(str(client_secret), SCOPES)
        creds = flow.run_local_server(port=0)
    token_path.write_text(creds.to_json(), encoding="utf-8")
    return creds


def upload_video(client_secret: Path, token_path: Path, video: Path,
                 metadata: dict) -> dict:
    metadata = validate_metadata(metadata)
    service = build("youtube", "v3", credentials=credentials(client_secret, token_path), cache_discovery=False)
    request = service.videos().insert(
        part="snippet,status",
        body={
            "snippet": {"title": metadata["title"], "description": metadata["description"],
                        "categoryId": "22"},
            "status": {"privacyStatus": metadata["privacy"],
                       "selfDeclaredMadeForKids": metadata["made_for_kids"]},
        },
        media_body=MediaFileUpload(str(video), mimetype="video/mp4", resumable=True),
    )
    response = None
    while response is None:
        _, response = request.next_chunk()
    return {"youtube_url": f"https://www.youtube.com/watch?v={response['id']}",
            "youtube_privacy": response.get("status", {}).get("privacyStatus")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--connect", action="store_true", help="Авторизовать родительский канал")
    args = parser.parse_args()
    if args.connect:
        root = Path(__file__).resolve().parent
        credentials(root / "client_secret.json", root / "token.json", interactive=True)
        print("YouTube подключён. После одобрения задайте данные ролика и нажмите «Загрузить на YouTube».")

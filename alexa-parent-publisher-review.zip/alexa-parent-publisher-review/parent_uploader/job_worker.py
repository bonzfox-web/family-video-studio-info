"""Only publishes a parent's explicitly imported file."""
import json
import sys
from pathlib import Path
from youtube import upload_video, YouTubeAccessLost, access_lost_error

def main():
    payload = json.load(sys.stdin)
    try:
        if payload["kind"] != "publish":
            raise ValueError("Unsupported worker operation")
        root = Path(__file__).resolve().parent
        output = Path(payload["output"]).resolve()
        if output.parent != (root / "data" / "rendered").resolve():
            raise ValueError("Video outside publisher storage")
        result = upload_video(root / "client_secret.json", root / "token.json",
                              output, payload["job"]["youtube_metadata"])
        print(json.dumps({"event":"result", **result}), flush=True)
    except Exception as exc:
        lost = isinstance(exc, YouTubeAccessLost) or access_lost_error(exc)
        print(json.dumps({"event":"error", "access_lost":lost,
                         "error":"Подключите Google заново." if lost else
                         "Загрузка не завершилась. Проверьте YouTube Studio перед повтором."},
                         ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()

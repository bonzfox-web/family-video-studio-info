const $ = s => document.querySelector(s);
let version = null, loggedIn = false, accepted = false, refreshing = false;
const say = text => $('#message').textContent = text || '';
const esc = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path, options={}) {
  const response = await fetch(path, {credentials:'same-origin', ...options});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (data.code === 'policy_required') show({role:'parent',policy:data.policy});
    throw new Error(data.detail || 'Не удалось выполнить действие');
  }
  return data;
}
function show(data) {
  loggedIn = data.role === 'parent'; accepted = data.policy?.accepted === true;
  version = data.policy?.version || null;
  $('#login').hidden = loggedIn; $('#logout').hidden = !loggedIn;
  $('#policy-gate').hidden = !loggedIn || accepted; $('#studio').hidden = !loggedIn || !accepted;
  if (!loggedIn) $('#jobs').replaceChildren();
  if (loggedIn && accepted) refresh();
}
$('#login-form').addEventListener('submit', async e => {
  e.preventDefault(); say('');
  try { show(await api('/api/login', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({role:'parent',password:e.currentTarget.elements.password.value})}));
    e.target.reset();
  } catch(error) { say(error.message); }
});
$('#logout').addEventListener('click', async () => {
  try { await api('/api/logout',{method:'POST'}); show({}); } catch(error) { say(error.message); }
});
$('#policy-form').addEventListener('submit', async e => {
  e.preventDefault(); const button=e.target.querySelector('button'); button.disabled=true;
  try { const data=await api('/api/policy/accept',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({accepted:e.target.elements.accepted.checked,version})}); show({role:'parent',policy:data.policy});
  } catch(error) { say(error.message); } finally { button.disabled=false; }
});
$('#import-form').addEventListener('submit', async e => {
  e.preventDefault(); const button=e.target.querySelector('button'); button.disabled=true; say('Копируем MP4…');
  try { const file=e.target.elements.video_file.files[0];
    if (!file || file.size > 2*1024**3) throw new Error('Выберите MP4 размером до 2 ГБ');
    await api('/api/jobs',{method:'POST',body:new FormData(e.target)}); e.target.reset();
    say('Файл добавлен. Просмотрите его и заполните данные отправки.'); await refresh();
  } catch(error) { say(error.message); } finally { button.disabled=false; }
});
const privacy={private:'Закрытое',unlisted:'По ссылке',public:'Открытое'};
function card(job) {
  const m=job.youtube_metadata || {};
  const file=job.has_video ? '<video controls playsinline preload="metadata" src="/api/jobs/'+encodeURIComponent(job.id)+'/video"></video>' : '<p class="hint">История прежней отправки. MP4 остаётся в семейной студии.</p>';
  const form=job.status==='approved' && job.has_video ? '<form data-publish="'+esc(job.id)+'"><h3>2. Подготовьте отправку</h3>'+
    '<label>Название на английском<input name="title" required maxlength="100" value="'+esc(m.title || '')+'"></label>'+
    '<label>Описание на английском<textarea name="description" rows="3" maxlength="5000">'+esc(m.description || '')+'</textarea></label>'+
    '<label>Доступность<select name="privacy">'+Object.entries(privacy).map(([v,l])=>'<option value="'+v+'"'+((m.privacy || 'private')===v?' selected':'')+'>'+l+'</option>').join('')+'</select></label>'+
    '<label>Аудитория<select name="made_for_kids" required><option value="">Выберите</option><option value="true"'+(m.made_for_kids===true?' selected':'')+'>Для детей</option><option value="false"'+(m.made_for_kids===false?' selected':'')+'>Не для детей</option></select></label>'+
    '<label><input name="reviewed" type="checkbox" required>Я лично проверил(а) ролик и имею право загрузить его в свой канал.</label>'+
    '<label><input name="privacy_accepted" type="checkbox" required>Я принимаю <a href="/privacy" target="_blank" rel="noopener">политику</a> и <a href="https://www.youtube.com/t/terms" target="_blank" rel="noopener noreferrer">Условия YouTube</a> для этой отправки.</label>'+
    '<button class="primary">Загрузить на YouTube</button><p class="hint">Не прошедший аудит проект может быть ограничен закрытыми загрузками независимо от выбранной доступности.</p></form>' : '';
  let link='';
  if (job.youtube_url && /^https:\/\/www\.youtube\.com\/watch\?v=[A-Za-z0-9_-]+$/.test(job.youtube_url))
    link='<p><a href="'+esc(job.youtube_url)+'" target="_blank" rel="noopener noreferrer">Открыть на YouTube</a></p><p>Доступность: '+esc(privacy[job.youtube_privacy] || 'проверьте в YouTube Studio')+'</p>';
  if (job.youtube_data_removed) link='<p>Сохранённые сведения YouTube удалены. Проверьте ролик в YouTube Studio.</p>';
  return '<article class="card" data-id="'+esc(job.id)+'"><div class="job-details"><h2>'+esc(job.filename || 'Прежняя отправка')+'</h2><p>'+esc(({approved:'Готов к отправке',uploading:'Загружается',uploaded:'Загружен'})[job.status] || job.status)+'</p>'+ (job.error?'<p>'+esc(job.error)+'</p>':'')+'</div><div class="job-media">'+file+'</div><div class="job-actions">'+form+link+
    (job.status!=='uploading'?'<button class="secondary danger" data-delete="'+esc(job.id)+'">Удалить из родительского инструмента</button>':'')+'</div></article>';
}
async function refresh() {
  if (!loggedIn || !accepted || refreshing) return;
  refreshing=true;
  try {
    const jobs=await api('/api/jobs');
    const state=await api('/api/youtube/connection');
    $('#connection').textContent = state.token_saved ? (state.check_status==='valid'?'Google подтвердил доступ.':state.check_status==='unavailable'?'Временная ошибка проверки; подключение сохранено.':'Подключение сохранено. Ожидается проверка Google.') : 'Подключение отсутствует. Запустите connect_parent.ps1.';
    $('#disconnect').disabled=state.disconnecting || state.checking || jobs.some(j=>j.status==='uploading');
    if (state.revocation_unconfirmed) $('#disconnect-result').textContent='Google не подтвердил отзыв. Проверьте разрешения в настройках Google.';
    const target=$('#jobs');
    for (const node of [...target.children]) if (!jobs.some(j=>j.id===node.dataset.id)) {
      node.querySelectorAll('video').forEach(v=>{v.pause();v.removeAttribute('src');v.load();}); node.remove();
    }
    for (const job of jobs) {
      let node=[...target.children].find(n=>n.dataset.id===job.id);
      const fingerprint=JSON.stringify([job.status,job.error,job.youtube_url,job.youtube_privacy,job.youtube_data_removed,job.has_video]);
      if (node?.dataset.fingerprint===fingerprint) continue;
      const container=document.createElement('div'); container.innerHTML=card(job); const next=container.firstElementChild;
      next.dataset.fingerprint=fingerprint;
      if (node) { node.querySelectorAll('video').forEach(v=>v.pause()); node.replaceWith(next); } else target.append(next);
    }
  } catch(error) { say(error.message); } finally { refreshing=false; }
}
document.addEventListener('submit', async e => {
  const form=e.target.closest('[data-publish]'); if (!form) return; e.preventDefault();
  const button=form.querySelector('button'); button.disabled=true;
  const data=Object.fromEntries(new FormData(form));
  data.made_for_kids=data.made_for_kids==='true'; data.reviewed=form.elements.reviewed.checked;
  data.privacy_accepted=form.elements.privacy_accepted.checked; data.privacy_version=version;
  try { await api('/api/jobs/'+encodeURIComponent(form.dataset.publish)+'/publish',
    {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    say('Загрузка началась. Дождитесь результата.'); await refresh();
  } catch(error) { say(error.message); } finally { button.disabled=false; }
});
document.addEventListener('click', async e => {
  const button=e.target.closest('[data-delete]'); if (!button) return;
  if (!confirm('Удалить локальную копию и запись из родительского инструмента? Ролик в семейной студии и на YouTube сохранятся.')) return;
  button.disabled=true;
  const media=button.closest('article').querySelector('video');
  if (media) { media.pause();media.removeAttribute('src');media.load(); }
  try { await api('/api/jobs/'+encodeURIComponent(button.dataset.delete)+'/delete',{method:'POST'});await refresh(); }
  catch(error) { say(error.message); if(media) media.src='/api/jobs/'+encodeURIComponent(button.dataset.delete)+'/video'; }
  finally { button.disabled=false; }
});
$('#disconnect').addEventListener('click', async () => {
  if (!confirm('Отключить доступ к YouTube и удалить сохранённые сведения YouTube? Видео сохранятся.')) return;
  try { const result=await api('/api/youtube/disconnect',{method:'POST'});$('#disconnect-result').textContent=result.revoked?'Google подтвердил отзыв доступа.':'Локальный доступ удалён; проверьте отзыв в Google.';await refresh(); }
  catch(error) {say(error.message);}
});
setInterval(refresh,5000);
api('/api/me').then(show).catch(error=>say(error.message));

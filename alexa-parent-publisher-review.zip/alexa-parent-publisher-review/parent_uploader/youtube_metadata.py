"""Validate the parent-authored metadata before starting a YouTube upload."""


def validate_metadata(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Неверные данные загрузки")
    title = payload.get("title")
    description = payload.get("description", "")
    privacy = payload.get("privacy", "private")
    audience = payload.get("made_for_kids")
    if not isinstance(title, str) or not title.strip() or len(title.strip()) > 100:
        raise ValueError("Введите название: от 1 до 100 символов")
    if not isinstance(description, str):
        raise ValueError("Описание должно быть текстом")
    if len(description.encode("utf-8")) > 5000:
        raise ValueError("Описание слишком длинное: максимум 5000 байт UTF-8")
    if any(char in title + description for char in "<>"):
        raise ValueError("В названии и описании нельзя использовать < и >")
    if privacy not in ("private", "unlisted", "public"):
        raise ValueError("Выберите видимость ролика")
    if not isinstance(audience, bool):
        raise ValueError("Выберите аудиторию ролика")
    return {"title": title.strip(), "description": description,
            "privacy": privacy, "made_for_kids": audience}
